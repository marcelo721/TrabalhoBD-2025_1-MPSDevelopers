package com.marcelo721.AcademicManagementSystem.web.dto.departmentDto;

public record DepartmentCourseDto(
        String name,
        Long code
) {
}
