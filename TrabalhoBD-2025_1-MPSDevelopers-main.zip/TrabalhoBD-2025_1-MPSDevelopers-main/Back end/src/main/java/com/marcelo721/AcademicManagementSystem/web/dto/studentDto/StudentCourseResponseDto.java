package com.marcelo721.AcademicManagementSystem.web.dto.studentDto;

import java.time.LocalDate;

public record StudentCourseResponseDto(
        String name,
        Long code
){
}
