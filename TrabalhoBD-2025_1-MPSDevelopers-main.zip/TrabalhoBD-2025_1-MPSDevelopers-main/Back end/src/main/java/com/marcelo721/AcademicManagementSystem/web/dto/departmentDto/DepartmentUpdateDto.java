package com.marcelo721.AcademicManagementSystem.web.dto.departmentDto;

public record DepartmentUpdateDto(
        String newName
) {
}
