# Teacher

- pode ver as disciplinas que ele leciona
- pode ver todas as matrículas de uma disciplina (que ele leciona)
- Poder mudar a nota final e a frequência em uma matrícula 