export const TOKEN_STORAGE_KEY = 'uniufc@token'
export const USER_STORAGE_KEY = 'uniufc@user'
