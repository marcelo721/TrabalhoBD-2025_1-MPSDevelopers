export type Phone = {
  description: number
  number: string
}
