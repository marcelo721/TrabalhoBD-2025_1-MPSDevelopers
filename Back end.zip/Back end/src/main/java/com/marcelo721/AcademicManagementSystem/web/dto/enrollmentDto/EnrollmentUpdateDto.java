package com.marcelo721.AcademicManagementSystem.web.dto.enrollmentDto;

public record EnrollmentUpdateDto(
        float finalGrade,
        float attendance
) {
}
