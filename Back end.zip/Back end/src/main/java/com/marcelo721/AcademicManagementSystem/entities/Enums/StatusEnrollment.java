package com.marcelo721.AcademicManagementSystem.entities.Enums;

//enum responsável por definir o status da matrícula do estudante em uma disciplina
public enum StatusEnrollment {
    IN_PROGRESS,
    FINISHED
}
