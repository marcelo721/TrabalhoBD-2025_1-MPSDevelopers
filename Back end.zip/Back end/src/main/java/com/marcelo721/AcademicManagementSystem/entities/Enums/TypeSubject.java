package com.marcelo721.AcademicManagementSystem.entities.Enums;

// Enum responsável por definir o tipo da disciplina
public enum TypeSubject {
    OBLIGATORY,
    OPTIONAL
}
