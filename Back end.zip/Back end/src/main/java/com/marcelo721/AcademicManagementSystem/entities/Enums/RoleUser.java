package com.marcelo721.AcademicManagementSystem.entities.Enums;

// enum responsável por caracterizar os tipos de usuários da aplicação
public enum RoleUser {
    TEACHER,
    EMPLOYEE,
    STUDENT,
    ADMIN
}
