package com.marcelo721.AcademicManagementSystem.web.dto.courseDto;

public record CourseDepartmentResponseDto(
        String name,
        Long code
) {
}
